 <!-- Vendor JS Files -->
 <script src="/template/assets/vendor/apexcharts/apexcharts.min.js"></script>
 <script src="/template/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
 <script src="/template/assets/vendor/chart.js/chart.min.js"></script>
 <script src="/template/assets/vendor/echarts/echarts.min.js"></script>
 <script src="/template/assets/vendor/quill/quill.min.js"></script>
 <!-- <script src="/template/assets/vendor/simple-datatables/simple-datatables.js"></script> -->
 <script src="/template/assets/vendor/tinymce/tinymce.min.js"></script>
 <script src="/template/assets/vendor/php-email-form/validate.js"></script>

 <!-- Template Main JS File -->
 <script src="/template/assets/js/main.js"></script>

 <!-- datatables -->
 <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
 <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>