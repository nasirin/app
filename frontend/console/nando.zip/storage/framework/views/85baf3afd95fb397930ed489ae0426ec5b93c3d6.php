

<?php $__env->startSection('content'); ?>
<div class="pagetitle">
    <h1>Profile</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
            <li class="breadcrumb-item">customer</li>
            <li class="breadcrumb-item active">Profile</li>
        </ol>
    </nav>
</div><!-- End Page Title -->

<section class="section profile">
    <div class="row">
        <div class="col-xl-4">

            <div class="card">
                <div class="card-body profile-card pt-4 d-flex flex-column align-items-center">

                    <img src="<?php echo e(url('storage/'.$customer['avatar'])); ?>" alt="Profile" class="rounded-circle">
                    <h2><?php echo e(ucwords($customer['first_name'].' '.$customer['last_name'])); ?></h2>
                    <h3>room</h3>
                </div>
            </div>
            <div class="card">
                <div class="card-body profile-card pt-4 d-flex flex-column align-items-center">

                    <img src="<?php echo e(url('storage/'.$customer['identity'])); ?>" alt="Profile" class="mb-2">
                    <h3>Identity</h3>
                </div>
            </div>

        </div>

        <div class="col-xl-8">

            <div class="card">
                <div class="card-body pt-3">
                    <!-- Bordered Tabs -->
                    <ul class="nav nav-tabs nav-tabs-bordered">

                        <li class="nav-item">
                            <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#profile-overview">Overview</button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#booking">Booking</button>
                        </li>

                        <li class="nav-item">
                            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-edit">Edit Profile</button>
                        </li>

                    </ul>
                    <div class="tab-content pt-2">

                        <div class="tab-pane fade show active profile-overview" id="profile-overview">
                            <h5 class="card-title">Profile Details</h5>

                            <div class="row">
                                <div class="col-lg-3 col-md-4 label ">First Name</div>
                                <div class="col-lg-9 col-md-8"><?php echo e($customer["first_name"]); ?></div>
                            </div>

                            <div class="row">
                                <div class="col-lg-3 col-md-4 label ">Last Name</div>
                                <div class="col-lg-9 col-md-8"><?php echo e($customer["last_name"]); ?></div>
                            </div>

                            <div class="row">
                                <div class="col-lg-3 col-md-4 label">Nick Name</div>
                                <div class="col-lg-9 col-md-8"><?php echo e($customer["nick_name"]); ?></div>
                            </div>

                            <div class="row">
                                <div class="col-lg-3 col-md-4 label">Address</div>
                                <div class="col-lg-9 col-md-8"><?php echo e($customer["address"]); ?></div>
                            </div>

                            <div class="row">
                                <div class="col-lg-3 col-md-4 label">Phone</div>
                                <div class="col-lg-9 col-md-8"><?php echo e($customer["phone"]); ?></div>
                            </div>

                            <div class="row">
                                <div class="col-lg-3 col-md-4 label">Email</div>
                                <div class="col-lg-9 col-md-8"><?php echo e($customer["email"]); ?></div>
                            </div>

                            <div class="row">
                                <div class="col-lg-3 col-md-4 label">Gender</div>
                                <div class="col-lg-9 col-md-8"><?php echo e($customer["gender"]); ?></div>
                            </div>
                            <div class="row">
                                <div class="col-lg-3 col-md-4 label">Status</div>
                                <div class="col-lg-9 col-md-8"><?php echo e($customer["status"]); ?></div>
                            </div>
                            <div class="row">
                                <div class="col-lg-3 col-md-4 label">Job</div>
                                <div class="col-lg-9 col-md-8"><?php echo e($customer["jobs"]); ?></div>
                            </div>
                        </div>
                        <div class="tab-pane fade show profile-overview" id="booking">
                            <h5 class="card-title">Booking Details</h5>

                            <?php $__currentLoopData = $booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row">
                                <div class="col-lg-3 col-md-4 label ">Room</div>
                                <div class="col-lg-9 col-md-8"><?php echo e($data['room']['no_room']); ?></div>
                            </div>
                            <div class="row">
                                <div class="col-lg-3 col-md-4 label ">Room Cost </div>
                                <div class="col-lg-9 col-md-8"><?php echo e('Rp '.number_format($data['cost'],0,',','.').'/'.$data['rental_type']); ?></div>
                                <!-- <div class="col-lg-9 col-md-8">Rp 500.000 (bulan | tahun)</div> -->
                            </div>

                            <div class="row">
                                <div class="col-lg-3 col-md-4 label ">Additional</div>
                                <div class="col-lg-9 col-md-8">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Additional</th>
                                                <th>Price</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data['booking_additional']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $add): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($key+1); ?></td>
                                                <td><?php echo e($add['additional']); ?></td>
                                                <td><?php echo e("Rp ".number_format($add['cost'],0,',','.')); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-3 col-md-4 label ">Billing</div>
                                <div class="col-lg-9 col-md-8">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Due date</th>
                                                <th>Billing</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data['billing']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $add): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($key+1); ?></td>
                                                <td><?php echo e($add['payment_due']); ?></td>
                                                <td><?php echo e("Rp ".number_format($add['total'],0,',','.')); ?></td>
                                                <td><?php echo e($add['payment_status']); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div class="tab-pane fade profile-edit pt-3" id="profile-edit">

                            <!-- Profile Edit Form -->
                            <form action="<?php echo e(url('customer/'.$customer['id'])); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('patch'); ?>

                                <div class="row mb-3">
                                    <label for="inputText" class="col-md-4 col-lg-3 col-form-label">First name</label>
                                    <div class="col-md-8 col-lg-9">
                                        <input type="text" class="form-control" name="first_name" value="<?php echo e($customer['first_name']); ?>">
                                        <?php if($errors->first('first_name')): ?>
                                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                            <i class="bi bi-exclamation-octagon me-1"></i>
                                            <?php echo e($errors->first('first_name')); ?>

                                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="inputText" class="col-md-4 col-lg-3 col-form-label">Last name</label>
                                    <div class="col-md-8 col-lg-9">
                                        <input type="text" class="form-control" name="last_name" value="<?php echo e($customer['last_name']); ?>">
                                        <?php if($errors->first('last_name')): ?>
                                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                            <i class="bi bi-exclamation-octagon me-1"></i>
                                            <?php echo e($errors->first('last_name')); ?>

                                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="inputText" class="col-md-4 col-lg-3 col-form-label">Nick name</label>
                                    <div class="col-md-8 col-lg-9">
                                        <input type="text" class="form-control" name="nick_name" value="<?php echo e($customer['nick_name']); ?>">
                                        <?php if($errors->first('nick_name')): ?>
                                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                            <i class="bi bi-exclamation-octagon me-1"></i>
                                            <?php echo e($errors->first('nick_name')); ?>

                                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="inputText" class="col-md-4 col-lg-3 col-form-label">Address</label>
                                    <div class="col-md-8 col-lg-9">
                                        <input type="text" class="form-control" name="address" value="<?php echo e($customer['address']); ?>">
                                        <?php if($errors->first('address')): ?>
                                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                            <i class="bi bi-exclamation-octagon me-1"></i>
                                            <?php echo e($errors->first('address')); ?>

                                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="inputNumber" class="col-md-4 col-lg-3 col-form-label">Phone Number</label>
                                    <div class="col-md-8 col-lg-9">
                                        <input type="number" class="form-control" name="phone" value="<?php echo e($customer['phone']); ?>">
                                        <?php if($errors->first('phone')): ?>
                                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                            <i class="bi bi-exclamation-octagon me-1"></i>
                                            <?php echo e($errors->first('phone')); ?>

                                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="inputEmail" class="col-md-4 col-lg-3 col-form-label">Email</label>
                                    <div class="col-md-8 col-lg-9">
                                        <input type="email" class="form-control" name="email" value="<?php echo e($customer['email']); ?>">
                                        <?php if($errors->first('email')): ?>
                                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                            <i class="bi bi-exclamation-octagon me-1"></i>
                                            <?php echo e($errors->first('email')); ?>

                                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="inputPassword" class="col-md-4 col-lg-3 col-form-label">Password</label>
                                    <div class="col-md-8 col-lg-9">
                                        <input type="password" class="form-control" name="password">
                                        <?php if($errors->first('password')): ?>
                                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                            <i class="bi bi-exclamation-octagon me-1"></i>
                                            <?php echo e($errors->first('password')); ?>

                                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <fieldset class="row mb-3">
                                    <legend class="col-form-label col-sm-2 pt-0">Gender</legend>
                                    <div class="col-md-8 col-lg-9">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="gender" id="gridRadios1" value="male" <?= $customer['gender'] == 'male' ? 'checked' : '' ?>>
                                            <label class="form-check-label" for="gridRadios1">
                                                Male
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="gender" id="gridRadios2" value="female" <?= $customer['gender'] == 'female' ? 'checked' : '' ?>>
                                            <label class="form-check-label" for="gridRadios2">
                                                Female
                                            </label>
                                        </div>
                                    </div>
                                </fieldset>
                                <fieldset class="row mb-3">
                                    <legend class="col-form-label col-sm-2 pt-0">Status</legend>
                                    <div class="col-md-8 col-lg-9">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="status" id="gridRadios4" value="single" <?= $customer['status'] == 'single' ? 'checked' : '' ?>>
                                            <label class="form-check-label" for="gridRadios1">
                                                Single
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="status" id="gridRadios3" value="married" <?= $customer['status'] == 'married' ? 'checked' : '' ?>>
                                            <label class="form-check-label" for="gridRadios2">
                                                Married
                                            </label>
                                        </div>
                                    </div>
                                </fieldset>
                                <fieldset class="row mb-3">
                                    <legend class="col-form-label col-sm-2 pt-0">Jobs</legend>
                                    <div class="col-md-8 col-lg-9">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="jobs" id="gridRadios5" value="student" <?= $customer['jobs'] == 'student' ? 'checked' : '' ?>>
                                            <label class="form-check-label" for="gridRadios1">
                                                Student
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="jobs" id="gridRadios6" value="worker" <?= $customer['jobs'] == 'worker' ? 'checked' : '' ?>>
                                            <label class="form-check-label" for="gridRadios2">
                                                Worker
                                            </label>
                                        </div>
                                    </div>
                                </fieldset>
                                <div class="row mb-3">
                                    <label for="inputNumber" class="col-md-4 col-lg-3 col-form-label">Photo</label>
                                    <div class="col-md-8 col-lg-9">
                                        <input class="form-control" type="file" id="formFile" name="avatar" accept="image/jpg, image/jpeg, image/png">
                                        <?php if($errors->first('avatar')): ?>
                                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                            <i class="bi bi-exclamation-octagon me-1"></i>
                                            <?php echo e($errors->first('avatar')); ?>

                                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="inputNumber" class="col-md-4 col-lg-3 col-form-label">Identity</label>
                                    <div class="col-md-8 col-lg-9">
                                        <input class="form-control" type="file" id="formFile" name="identity" accept="image/jpg, image/jpeg, image/png">
                                        <?php if($errors->first('identity')): ?>
                                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                            <i class="bi bi-exclamation-octagon me-1"></i>
                                            <?php echo e($errors->first('identity')); ?>

                                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="text-center">
                                    <button type="submit" class="btn btn-primary">Save Changes</button>
                                </div>
                            </form><!-- End Profile Edit Form -->

                        </div>
                    </div><!-- End Bordered Tabs -->

                </div>
            </div>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\nando\app\frontend\console\resources\views/pages/customer/profil.blade.php ENDPATH**/ ?>