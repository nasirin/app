

<?php $__env->startSection('content'); ?>
<div class="pagetitle">
    <h1>Data Rooms</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">Home</a></li>
            <li class="breadcrumb-item">Tables</li>
            <li class="breadcrumb-item active">rooms</li>
        </ol>
    </nav>
</div><!-- End Page Title -->

<section class="section">
    <div class="row">
        <div class="col-lg-12">

            <?php echo $__env->make('partials.alertSuccess', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="card">
                <div class="card-body">
                    <a href="/room/create" class="btn  btn-primary btn-sm my-2">Add Room</a>

                    <!-- Table with stripped rows -->
                    <table class="table" id="myTable">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">No Room</th>
                                <th scope="col">Location</th>
                                <th scope="col">Type</th>
                                <th scope="col">Status</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($key+1); ?></th>
                                <td><?php echo e($room["no_room"]); ?></td>
                                <td><?php echo e($room["location"]); ?></td>
                                <td><?php echo e($room["type"]); ?></td>
                                <td><?php echo e($room["status"]); ?></td>
                                <td>
                                    <a href="<?php echo e(url('room/'.$room['id'])); ?>" class="btn btn-info btn-sm"> <i class="ri-eye-2-line"></i></a>
                                    <a href="<?php echo e(url('room/'.$room['id'].'/edit')); ?>" class="btn btn-warning btn-sm"> <i class="bx bxs-edit"></i></a>
                                    <form action="<?php echo e(url('room/'.$room['id'])); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button onclick="return confirm('apakah anda yakin?')" class="btn btn-danger btn-sm"><i class="bx bxs-trash"></i></button>
                                    </form>
                                    <a href="#" title="Add Booking" class="btn btn-info btn-sm"> <i class="ri-book-2-fill"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <!-- End Table with stripped rows -->

                </div>
            </div>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\nando\app\frontend\console\resources\views/pages/rooms/index.blade.php ENDPATH**/ ?>