

<?php $__env->startSection('content'); ?>
<div class="pagetitle">
    <h1>Data Customers</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">Home</a></li>
            <li class="breadcrumb-item">Tables</li>
            <li class="breadcrumb-item active">Data</li>
        </ol>
    </nav>
</div>

<section class="section">
    <div class="row">
        <div class="col-lg-12">
            <?php echo $__env->make('partials.alertSuccess', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="card">
                <div class="card-body">

                    <a href="<?php echo e(route('customer.create')); ?>" class="btn  btn-primary btn-sm my-2"><i class="bx bxs-file-plus"></i>Tambah customer</a>

                    <!-- Table with stripped rows -->
                    <table class="table" id="myTable">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name</th>
                                <th scope="col">Address</th>
                                <th scope="col">Phome</th>
                                <th scope="col">Job</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($customer as $key => $value) : ?>
                                <tr>
                                    <th scope="row"><?= $key + 1 ?></th>
                                    <td><?= $value['nick_name'] ?></td>
                                    <td><?= $value['address'] ?></td>
                                    <td><?= $value['phone'] ?></td>
                                    <td><?= $value['jobs'] ?></td>
                                    <td>
                                        <a href="<?php echo e(url('customer/'.$value['id'])); ?>" class="btn btn-info btn-sm"> <i class="ri-eye-2-line"></i></a>
                                        <a href="<?php echo e(url('customer/'.$value['id'].'/edit')); ?>" class="btn btn-warning btn-sm"> <i class="bx bxs-edit"></i></a>
                                        <form action="<?php echo e(url('customer/'.$value['id'])); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button onclick="return confirm('apakah anda yakin?')" class="btn btn-danger btn-sm"><i class="bx bxs-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach ?>
                        </tbody>
                    </table>
                    <!-- End Table with stripped rows -->

                </div>
            </div>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\nando\app\frontend\console\resources\views/pages/customer/index.blade.php ENDPATH**/ ?>