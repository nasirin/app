<?php if(session('message')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <i class="bi bi-check-circle me-1"></i>
    <?php echo e(session('message')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?><?php /**PATH D:\project\nando\app\frontend\console\resources\views/partials/alertSuccess.blade.php ENDPATH**/ ?>