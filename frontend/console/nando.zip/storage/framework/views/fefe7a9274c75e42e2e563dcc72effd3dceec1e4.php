
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
    <h1>Update Necessity</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">Home</a></li>
            <li class="breadcrumb-item">Forms Necessity</li>
        </ol>
    </nav>
</div><!-- End Page Title -->

<section class="section">
    <div class="row">
        <div class="col-12">

            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Form Necessity</h5>

                    <!-- General Form Elements -->
                    <form action="<?php echo e(url('/necessities/'.$necessities['id'])); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('patch'); ?>
                        <div class="row mb-3">
                            <label for="inputText" class="col-sm-2 col-form-label">Necessity</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" required name="necessity" value="<?php echo e($necessities['necessity']); ?>">
                                <?php if($errors->first('necessity')): ?>
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <i class="bi bi-exclamation-octagon me-1"></i>
                                    <?php echo e($errors->first('necessity')); ?>

                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="inputEmail" class="col-sm-2 col-form-label">Cost</label>
                            <div class="col-sm-10">
                                <input type="number" min="0" class="form-control" required name="cost" value="<?php echo e($necessities['cost']); ?>">
                                <?php if($errors->first('cost')): ?>
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <i class="bi bi-exclamation-octagon me-1"></i>
                                    <?php echo e($errors->first('cost')); ?>

                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="inputPassword" class="col-sm-2 col-form-label">Date</label>
                            <div class="col-sm-10">
                                <input type="date" class="form-control" name="tanggal" required value="<?php echo e($necessities['tanggal']); ?>">
                                <?php if($errors->first('tanggal')): ?>
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <i class="bi bi-exclamation-octagon me-1"></i>
                                    <?php echo e($errors->first('tanggal')); ?>

                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="inputPassword" class="col-sm-2 col-form-label">Pcs</label>
                            <div class="col-sm-10">
                                <input type="number" min="0" class="form-control" name="pcs" required value="<?php echo e($necessities['pcs']); ?>">
                                <?php if($errors->first('pcs')): ?>
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <i class="bi bi-exclamation-octagon me-1"></i>
                                    <?php echo e($errors->first('pcs')); ?>

                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="inputPassword" class="col-sm-2 col-form-label">Nota</label>
                            <div class="col-sm-10">
                                <input type="file" class="form-control" name="file" accept="image/png,image/jpg,image/jpeg">
                                <img src="<?php echo e(url('storage/'.$necessities['file'])); ?>" width="300" class="mt-2" alt="">
                                <?php if($errors->first('file')): ?>
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <i class="bi bi-exclamation-octagon me-1"></i>
                                    <?php echo e($errors->first('file')); ?>

                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-sm-10">
                                <button type="submit" class="btn btn-primary">Submit Form</button>
                            </div>
                        </div>

                    </form><!-- End General Form Elements -->

                </div>
            </div>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\nando\app\frontend\console\resources\views/pages/necessities/ubah.blade.php ENDPATH**/ ?>